import React, { Component, Fragment } from 'react';
import { Router, Route, Redirect, Switch } from 'react-router-dom';
import NotesApp from '../components/NotesApp';
import EditNote from '../components/EditNote';
import EditReminder from '../components/EditReminder';
import WelcomePage from '../components/WelcomePage';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { blue, pink } from '@material-ui/core/colors';
import Header from '../components/Header';
import { createBrowserHistory } from 'history';

export const history = createBrowserHistory();
const theme = createMuiTheme({
    palette: {
        primary: blue,
        secondary: pink,
    },
    typography: {
        useNextVariants: true,
    },
});

const PrivateRoute = ({ component: Component, isAuthenticated, ...rest }) => (
    <Route {...rest} render={(props) => (
        localStorage.getItem('isLoggedIn')
            ? <Component {...props} {...rest} />
            : <Redirect to="/" />
    )} />
);

class AppRouter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            originalNotes: [],
            notes: [],
            reminders : [],
            originalReminders :[],
            currentPage: 'notes',
        };
        this.handleAddNote = this.handleAddNote.bind(this);
        this.handleRemoveNote = this.handleRemoveNote.bind(this);
        this.handleUpdateNote = this.handleUpdateNote.bind(this);
        this.handleSearchNote = this.handleSearchNote.bind(this);
        this.handleCurrentPage = this.handleCurrentPage.bind(this);
        this.handleAddReminder =this.handleAddReminder.bind(this);
        this.handleUpdateReminder= this.handleUpdateReminder.bind(this);
        this.handleRemoveReminder=this.handleRemoveReminder.bind(this);
    }

    componentDidMount() {
        let userid = localStorage.getItem('LoggedInUser');
        // Get all the notes
        fetch(`http://localhost:8082/noteservice/api/v1/note/${userid}`)
            .then(response => response.json())
            .then(success => this.setState({
                notes: success,
                originalNotes: success,
            }))

            // Get all the reminders
        fetch(`http://localhost:9000/reminderservice/api/v1/reminder`)
        .then(response => response.json())
        .then(reminderSuccess => this.setState({
            reminders: reminderSuccess,
            originalReminders: reminderSuccess,
        }))
    }
    handleCurrentPage(currentPage){
        this.setState((currState) => ({
            currentPage: currentPage,
        }));

    }

    handleAddNote(note) {
        console.log(note);
        fetch('http://localhost:8082/noteservice/api/v1/note', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(note)
        }).then(response => response.json())
          .then(note => {
            this.setState((currState) => ({
                notes: currState.notes.concat([note]),
                originalNotes: currState.notes.concat([note])
            }));
                
            });
        // Post a new note
    }

    handleAddReminder(reminder) {
        console.log("reminder check  " + JSON.stringify(reminder));
        fetch('http://localhost:9000/reminderservice/api/v1/reminder', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(reminder)
        }).then(response => response.json())
          .then(reminder => {
            this.setState((currState) => ({
                reminders: currState.reminders.concat([reminder]),
                originalReminders: currState.reminders.concat([reminder])
            }));
                
            });
        // Post a new note
    }
    handleRemoveNote(noteId) {
        let userid = localStorage.getItem('LoggedInUser');
        fetch(`http://localhost:8082/noteservice/api/v1/note/${userid}/${noteId}`, {
            method: 'DELETE',
            headers: { "Content-Type": "application/json" }
        })
          //  .then(response => response.json())
            .then(response => {
                const noteIndexToRemove = this.state.notes.findIndex(note => note.id === noteId);
                this.setState((currState) => ({
                    notes: [...currState.notes.slice(0, noteIndexToRemove), ...currState.notes.slice(noteIndexToRemove + 1)],
                    originalNotes: [...currState.notes.slice(0, noteIndexToRemove), ...currState.notes.slice(noteIndexToRemove + 1)]
                }));
            });
    }


    handleRemoveReminder(reminderId) {
        console.log("reminder ka" +reminderId);
        fetch(`http://localhost:9000/reminderservice/api/v1/reminder/${reminderId}`, {
            method: 'DELETE',
            headers: { "Content-Type": "application/json" }
        })
          //  .then(response => response.json())
            .then(response => {
                const remIndexToRemove = this.state.reminders.findIndex(reminder => reminder.reminderId === reminderId);
                console.log("reminder ka index"+ remIndexToRemove);
                this.setState((currState) => ({ 
                    reminders: [...currState.reminders.slice(0, remIndexToRemove), ...currState.reminders.slice(remIndexToRemove + 1)],
                    originalReminders: [...currState.reminders.slice(0, remIndexToRemove), ...currState.reminders.slice(remIndexToRemove + 1)]
                }));
            });
    }

    handleUpdateNote(updatedNote) {
        let userid = localStorage.getItem('LoggedInUser');
        fetch(`http://localhost:8082/noteservice/api/v1/note/${userid}/${updatedNote.id}`, {
            method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedNote)
        })
            .then(response => response.json())
            .then(note => {
                const noteIndexToUpdate = this.state.notes.findIndex(note => note.id === updatedNote.id);
        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToUpdate), { ...updatedNote }, ...currState.notes.slice(noteIndexToUpdate + 1)],
            originalNotes: [...currState.notes.slice(0, noteIndexToUpdate), { ...updatedNote }, ...currState.notes.slice(noteIndexToUpdate + 1)]
        }));
            });
    }
    handleUpdateReminder(updatedReminder) {
        console.log("updatedReminder"+JSON.stringify(updatedReminder));
        fetch(`http://localhost:9000/reminderservice/api/v1/reminder/${updatedReminder.reminderId}`, {
            method: 'PUT',
            crossDomain:true,
            headers: { "Content-Type": "application/json",'Access-Control-Allow-Origin':'*' },
            body: JSON.stringify(updatedReminder)
        })
            .then(response => response.json())
            .then(reminder => {
                const remIndexToUpdate = this.state.reminders.findIndex(reminder => reminder.reminderId === updatedReminder.reminderId);
        this.setState((currState) => ({
            reminders: [...currState.reminders.slice(0, remIndexToUpdate), { ...updatedReminder }, ...currState.reminders.slice(remIndexToUpdate + 1)],
            originalReminders: [...currState.reminders.slice(0, remIndexToUpdate), { ...updatedReminder }, ...currState.reminders.slice(remIndexToUpdate + 1)]
        }));

        
            });
    }

    handleSearchNote(event) {
        let searchCondition = event.target.value.toLowerCase();
        searchCondition ?
            this.setState((currState) => ({
                notes: currState.originalNotes.filter(note => (note.noteTitle.toLowerCase().indexOf(searchCondition) > -1 || note.noteDescription.toLowerCase().indexOf(searchCondition) > -1))
            }))
            : this.setState((currState) => ({
                notes: currState.originalNotes
            }))

    }

    render() {
        return (
            <Fragment>
                <MuiThemeProvider theme={theme}>
                    <Header handleSearchNote={this.handleSearchNote} 
                    handleCurrentPage={this.handleCurrentPage} 
                    currentPage={this.state.currentPage}/>
                    <Router history={history}>
                        <Switch>
                            <Route
                                path="/"
                                render={(props) => (<WelcomePage />)}
                                exact
                            />
                            <PrivateRoute
                                path="/home"
                                exact
                                component={NotesApp}
                                notes={this.state.notes}
                                handleAddNote={this.handleAddNote}
                                handleRemoveNote={this.handleRemoveNote}
                                currentPage={this.state.currentPage}
                                reminders={this.state.reminders}
                                handleAddReminder={this.handleAddReminder}
                                handleRemoveReminder={this.handleRemoveReminder}
                                handleUpdateReminder={this.handleUpdateReminder}
                               
                            />

{/* <PrivateRoute
                                path="/rem"
                                exact
                                component={NotesApp}
                                reminders={this.state.reminders}
                                handleAddReminder={this.handleAddReminder}
                                handleRemoveReminder={this.handleRemoveReminder}
                                currentPage={this.state.currentPage}
                            /> */}
                            {/* <Route
                                path="/home"
                                render={(props) => (<NotesApp
                                    {...props}
                                    notes={this.state.notes}
                                    handleAddNote={this.handleAddNote}
                                    handleRemoveNote={this.handleRemoveNote}
                                />)}
                                exact
                            /> */}
                            <PrivateRoute
                                path="/edit-note/:id"
                                exact
                                component={EditNote}
                                notes={this.state.notes}
                                handleUpdateNote={this.handleUpdateNote}
                            />}
                            <PrivateRoute
                                path="/edit-reminder/:reminderId"
                                exact
                                component={EditReminder}
                                reminders={this.state.reminders}
                                handleUpdateReminder={this.handleUpdateReminder}
                            />}
                        />
                        </Switch>
                    </Router>
                </MuiThemeProvider>
            </Fragment>
        );
    }
}

export default AppRouter;