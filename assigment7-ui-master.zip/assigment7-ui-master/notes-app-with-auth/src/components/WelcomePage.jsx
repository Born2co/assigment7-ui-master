import React from 'react';

import notepad from '../images/notepad.png';




const WelcomePage = () => (

    <React.Fragment>
        <center>
            <div><h1>NOTEPAD</h1></div>
        </center>
        <marquee><h3>A Simple App For Your Note Making Need On Go!</h3></marquee>
        <center>
            <img
                src={notepad} height="40%" width="40%"/>
                </center>
        
    </React.Fragment>


);

export default WelcomePage;