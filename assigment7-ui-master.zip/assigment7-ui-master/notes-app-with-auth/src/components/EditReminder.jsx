import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { withStyles } from '@material-ui/core';
import ColorPicker from 'react-color';
import ColorLensIcon from '@material-ui/icons/ColorLens';

const styles = theme => ({
    swatch: {
        padding: '5px',
        background: '#fff',
        borderRadius: '1px',
        boxShadow: '0 0 0 1px rgba(0,0,0,.1)',
        display: 'inline-block',
        cursor: 'pointer',
    },
    popover: {
        position: 'fixed',
        zIndex: '2',
    },
});

class EditReminder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            open: true,
            reminderName: this.props.reminders.filter(reminder => reminder.reminderId === this.props.match.params.reminderId)[0].reminderName,
            reminderDescription: this.props.reminders.filter(reminder => reminder.reminderId === this.props.match.params.reminderId)[0].reminderDescription,
            
            background: 'black',
        }
        this.handleClickOpen = this.handleClickOpen.bind(this);
        this.handleUpdateReminder = this.handleUpdateReminder.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleReminderTitleChange = this.handleReminderTitleChange.bind(this);
        this.handleReminderDescriptionChange = this.handleReminderDescriptionChange.bind(this);
    }

    handleClickOpen() {
        this.setState({ open: true });
    }

    handleClose() {
        this.setState({
            open: false,
            reminderName: '',
            reminderDescription: '',
        });
        this.props.history.push('/home');
    }

    handleReminderTitleChange(event) {
        this.setState({ reminderName: event.target.value });
    }

    handleReminderDescriptionChange(event) {
        this.setState({ reminderDescription: event.target.value });
    }

    handleUpdateReminder() {
        const updatedReminder = {
            reminderId: this.props.match.params.reminderId,
            reminderName: this.state.reminderName,
            reminderDescription: this.state.reminderDescription,
            color: this.state.color,
        }
        this.props.handleUpdateReminder(updatedReminder);
        this.handleClose();
    }
    handleClick = () => {
        this.setState({ displayColorPicker: !this.state.displayColorPicker })
    };

    handleColorClose = () => {
        this.setState({ displayColorPicker: false })
    };

    handleChange = (color) => {
        this.setState({ color: color.rgb, background: color.hex })
    };
    render() {
        const { classes } = this.props;
        const cover = {
            position: 'fixed',
            top: '0px',
            right: '0px',
            bottom: '0px',
            left: '0px',
        }
        return (
            <Dialog
                open={this.state.open}
                onClose={this.handleClose}
                aria-labelledby="Edit reminder form"
               
            >
                <DialogTitle id="Edit reminder form">
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        Edit Reminder
                            <div style={styles.swatch} onClick={this.handleClick}>
                            {/* <ColorLensIcon className={classes.iconHover} style={{ fontSize: 30, color: this.state.background }} /> */}
                        </div>
                        {/* {this.state.displayColorPicker ? <div className={classes.popover}>
                            <div style={cover} onClick={this.handleColorClose} />
                            <ColorPicker color={this.state.color}
                                onChangeComplete={this.handleChange} />
                        </div> : null} */}
                    </div>
                </DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="reminder title"
                        label="Reminder Title"
                        type="text"
                        fullWidth
                        onChange={this.handleReminderTitleChange}
                        value={this.state.reminderName}
                    />
                    <TextField
                        margin="dense"
                        id="reminder description"
                        label="Reminder Description"
                        type="text"
                        onChange={this.handleReminderDescriptionChange}
                        value={this.state.reminderDescription}
                        fullWidth
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} color="primary">
                        Cancel
                        </Button>
                    <Button onClick={this.handleUpdateReminder} color="primary">
                        Update
                    </Button>
                </DialogActions>
            </Dialog>
        );
    }
}

export default withStyles(styles)(EditReminder);